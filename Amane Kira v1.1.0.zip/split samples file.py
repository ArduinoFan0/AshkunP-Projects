import wave
import os
file_dir = os.path.dirname(__file__)
phonemes = """a
    i
    u
    e
    o
    ka
    ki
    ku
    ke
    ko
    sa
    shi
    su
    se
    so
    ta
    chi
    tsu
    te
    to
    na
    ni
    nu
    ne
    no
    ha
    hi
    fu
    he
    ho
    ma
    mi
    mu
    me
    mo
    ya
    yu
    yo
    ra
    ri
    ru
    re
    ro
    wa
    wo
    n
    ga
    gi
    gu
    ge
    go
    za
    ji
    zu
    ze
    zo
    da
    dji
    dzu
    de
    do
    ba
    bi
    bu
    be
    bo
    pa
    pi
    pu
    pe
    po
    kya
    kyu
    kyo
    gya
    gyu
    gyo
    sha
    shu
    sho
    ja
    ju
    jo
    cha
    chu
    cho
    nya
    nyu
    nyo
    hya
    hyu
    hyo
    bya
    byu
    byo
    pya
    pyu
    pyo
    mya
    myu
    myo
    rya
    ryu
    ryo"""
with wave.open(f"{file_dir}\\samples.wav", "rb") as f:
    frames = f.getnframes()
    samplerate = f.getframerate()
    wave_data = f.readframes(frames)
    for n,phoneme_name in enumerate(phonemes.split("\n")):
        phoneme_wave_data = wave_data[max(round((n*2-0.2)*samplerate),0):round((n*2+1.2)*samplerate)]
        with wave.open(f"{file_dir}\\{phoneme_name.strip()}.wav", "wb") as o:
            o.setnchannels(1)
            o.setsampwidth(2)
            o.setframerate(samplerate)
            o.writeframes(phoneme_wave_data)